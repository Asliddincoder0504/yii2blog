<?php

namespace ElementorPro\Core\Admin;

class Post_Status {
	public const PUBLISH = 'publish';
	public const PRIVATE = 'private';
	public const DRAFT = 'draft';
}
